import json
mahasiswa = None
with open('mahasiswa.json','r') as file:
    mahasiswa = json.load(file)
    jumlah = input(print('masukan jumlah mahasiswa baru: '))
    for x in range(0,len(jumlah)):
        print(x)
        nama = input(print('masukan jumlah nama anda: '))
        hobi = input(print('masukan jumlah hobi anda: '))
        prestasis = input(print('masukan prestasi anda: '))
        for i in range(0,len(hobi)):
            print(i)
        entry = {nama : 'biodata' ,'hobi' : [i] ,'prestasi' : prestasis }

    print(entry)
    dict.update(entry)
with open('mahasiswa.json','w') as file:
    json.dump(mahasiswa, file)

